/* ============================================================
   DASHBOARD.JS
   ============================================================ */

document.addEventListener('DOMContentLoaded', async () => {
  requireAuth();
  loadUserProfile();
  await loadHistory();
});

function loadUserProfile() {
  const user = getUser();
  if (!user) return;
  const fullName = `${user.first_name || ''} ${user.last_name || ''}`.trim();
  setText('userName',  fullName || 'User');
  setText('userEmail', user.email || '—');
  setText('sAge',      user.age    ? `${user.age} yrs`  : '—');
  setText('sGender',   capitalize(user.gender || '—'));
  const av = document.getElementById('avatarEl');
  if (av && fullName) av.textContent = fullName[0].toUpperCase();
}

async function loadHistory() {
  try {
    const data = await apiHistory();
    const records = data.history || [];

    updateStatCards(records);
    renderChart(records);
    renderTable(records);

  } catch (err) {
    console.error('History load failed:', err);
    showEmptyState();
  }
}

function updateStatCards(records) {
  if (!records.length) {
    ['latestHb','latestStatus','totalTests','avgHb'].forEach(id => setText(id, '—'));
    setText('sTotalScans', '0');
    setText('sLastScan', '—');
    return;
  }

  const latest = records[0];
  const avgHb  = (records.reduce((s, r) => s + parseFloat(r.hb_level || 0), 0) / records.length).toFixed(1);

  setText('latestHb',     parseFloat(latest.hb_level).toFixed(1));
  setText('totalTests',   records.length);
  setText('avgHb',        avgHb);
  setText('sTotalScans',  records.length);
  setText('sLastScan',    formatDate(latest.created_at));

  const statusEl = document.getElementById('latestStatus');
  if (statusEl) {
    const isAnaemic = latest.prediction === 'anaemic';
    statusEl.textContent  = isAnaemic ? 'Anaemic' : 'Non-Anaemic';
    statusEl.style.color  = isAnaemic ? 'var(--crimson)' : 'var(--success)';
  }
}

function renderChart(records) {
  const canvas = document.getElementById('hbChart');
  if (!canvas) return;

  const sorted = [...records].reverse();
  const labels = sorted.map((r, i) => formatDateShort(r.created_at) || `Test ${i+1}`);
  const values = sorted.map(r => parseFloat(r.hb_level).toFixed(1));
  const threshold = new Array(sorted.length).fill(12);

  new Chart(canvas, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: 'Hb Level (g/dL)',
          data: values,
          borderColor: '#C0152A',
          backgroundColor: 'rgba(192,21,42,0.07)',
          borderWidth: 2.5,
          pointRadius: 5,
          pointBackgroundColor: '#C0152A',
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          fill: true,
          tension: 0.4,
        },
        {
          label: 'Anaemia Threshold',
          data: threshold,
          borderColor: '#B07800',
          borderWidth: 1.5,
          borderDash: [6, 4],
          pointRadius: 0,
          fill: false,
          tension: 0,
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#2C2C34',
          titleColor: '#fff',
          bodyColor: 'rgba(255,255,255,0.75)',
          padding: 12,
          callbacks: {
            label: ctx => ` ${ctx.dataset.label}: ${ctx.raw} g/dL`
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { color: '#8A8A98', font: { size: 11 } }
        },
        y: {
          min: 4, max: 18,
          grid: { color: 'rgba(0,0,0,0.05)' },
          ticks: { color: '#8A8A98', font: { size: 11 }, callback: v => v + ' g/dL' }
        }
      }
    }
  });
}

function renderTable(records) {
  const loading = document.getElementById('historyLoading');
  const empty   = document.getElementById('historyEmpty');
  const table   = document.getElementById('historyTable');
  const body    = document.getElementById('historyBody');
  const count   = document.getElementById('historyCount');

  if (loading) loading.style.display = 'none';

  if (!records.length) {
    if (empty) empty.style.display = 'flex';
    return;
  }

  if (count) count.textContent = `${records.length} records`;
  if (table) table.style.display = 'table';

  body.innerHTML = records.map((r, i) => {
    const isAnaemic = r.prediction === 'anaemic';
    const conf      = Math.round((r.confidence || 0) * 100);
    return `
      <tr>
        <td>${i + 1}</td>
        <td>${formatDate(r.created_at)}</td>
        <td><strong>${parseFloat(r.hb_level).toFixed(1)}</strong> g/dL</td>
        <td>
          <span class="status-pill ${isAnaemic ? 'anaemic' : 'non-anaemic'}">
            ${isAnaemic ? '🔴 Anaemic' : '🟢 Non-Anaemic'}
          </span>
        </td>
        <td>
          <div class="conf-bar">
            <div class="conf-track">
              <div class="conf-fill" style="width:${conf}%"></div>
            </div>
            <span class="conf-pct">${conf}%</span>
          </div>
        </td>
        <td>
          <button class="view-btn" onclick="viewResult('${r.id}')">View →</button>
        </td>
      </tr>
    `;
  }).join('');
}

function viewResult(id) {
  localStorage.setItem('haemo_last_result_id', id);
  window.location.href = 'result.html?id=' + id;
}

function showEmptyState() {
  const loading = document.getElementById('historyLoading');
  const empty   = document.getElementById('historyEmpty');
  if (loading) loading.style.display = 'none';
  if (empty)   empty.style.display   = 'flex';
}

/* ── Helpers ── */
function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}
function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
function formatDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('en-IN', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
}
function formatDateShort(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleDateString('en-IN', { day:'2-digit', month:'short' });
}

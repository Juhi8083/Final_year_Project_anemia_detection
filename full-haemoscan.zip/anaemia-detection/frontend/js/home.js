/* ============================================================
   HOME.JS — Scroll animations & nav effects
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  // Nav scroll effect
  const nav = document.querySelector('.nav');
  window.addEventListener('scroll', () => {
    nav.style.boxShadow = window.scrollY > 20 ? '0 2px 20px rgba(0,0,0,0.08)' : 'none';
  });

  // Intersection observer for fade-in animations
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

  document.querySelectorAll('.step, .feature-card, .hero-stats .stat').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    observer.observe(el);
  });

  document.addEventListener('animationend', (e) => {
    if (e.target.style.opacity === '0') {
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
    }
  });

  // Add visible class trigger
  document.querySelectorAll('.step, .feature-card, .hero-stats .stat').forEach((el, i) => {
    const io = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          el.style.opacity = '1';
          el.style.transform = 'translateY(0)';
        }, i * 80);
        io.unobserve(el);
      }
    }, { threshold: 0.1 });
    io.observe(el);
  });

  // Redirect "Start Eye Scan" to login if not logged in
  const startBtn = document.querySelector('a[href="pages/upload.html"]');
  if (startBtn) {
    startBtn.addEventListener('click', (e) => {
      if (!localStorage.getItem('haemo_token')) {
        e.preventDefault();
        window.location.href = 'pages/login.html';
      }
    });
  }
});

// Expose isLoggedIn globally for home page
function isLoggedIn() { return !!localStorage.getItem('haemo_token'); }

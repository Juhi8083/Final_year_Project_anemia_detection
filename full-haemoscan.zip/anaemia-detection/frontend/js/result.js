/* ============================================================
   RESULT.JS
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  requireAuth();
  loadResult();
});

const ADVICE_DATA = {
  anaemic: [
    { icon: '🥩', title: 'Iron-Rich Foods', text: 'Eat red meat, spinach, lentils, kidney beans, tofu, and fortified cereals daily.' },
    { icon: '🍊', title: 'Vitamin C Boost', text: 'Consume citrus fruits, tomatoes, and bell peppers alongside iron-rich meals to enhance absorption.' },
    { icon: '💊', title: 'Consult a Doctor', text: 'Visit a haematologist or general physician for blood tests and possible iron or B12 supplements.' },
  ],
  severe: [
    { icon: '🏥', title: 'Seek Immediate Care', text: 'Severe anaemia requires urgent medical attention. Please visit a hospital immediately.' },
    { icon: '💉', title: 'Iron Infusion', text: 'IV iron or blood transfusion may be needed — this is a medical decision by your doctor.' },
    { icon: '🚫', title: 'Avoid Strenuous Activity', text: 'Rest and avoid physical exertion until haemoglobin levels are stabilised under medical supervision.' },
  ],
  normal: [
    { icon: '✅', title: 'Maintain Your Diet', text: 'Keep up a balanced diet rich in iron, folate, and B12 to maintain healthy haemoglobin levels.' },
    { icon: '🏃', title: 'Stay Active', text: 'Regular moderate exercise helps maintain healthy red blood cell production.' },
    { icon: '📅', title: 'Regular Check-ups', text: 'Continue periodic screening every 6 months, especially if you are pregnant or a growing adolescent.' },
  ]
};

function loadResult() {
  // Try URL param first, then localStorage
  const params   = new URLSearchParams(window.location.search);
  const resultId = params.get('id');
  let result;

  if (resultId) {
    // Could fetch from API — here we use localStorage cache
    result = JSON.parse(localStorage.getItem('haemo_last_result') || 'null');
  } else {
    result = JSON.parse(localStorage.getItem('haemo_last_result') || 'null');
  }

  if (!result) {
    // Demo / fallback mode
    result = generateDemoResult();
  }

  renderResult(result);
}

function renderResult(result) {
  const hb         = parseFloat(result.hb_level  || result.haemoglobin || 11.2).toFixed(1);
  const confidence  = parseFloat(result.confidence || 0.87);
  const prediction  = (result.prediction || 'anaemic').toLowerCase();
  const isAnaemic   = prediction === 'anaemic';
  const imageUrl    = result.image_url || result.image || '../assets/eye-placeholder.png';
  const createdAt   = result.created_at || new Date().toISOString();

  // Date
  const dateEl = document.getElementById('resultDate');
  if (dateEl) dateEl.textContent = new Date(createdAt).toLocaleString('en-IN', { dateStyle:'long', timeStyle:'short' });

  // Status card
  const card = document.getElementById('statusCard');
  if (card) card.classList.add(isAnaemic ? 'is-anaemic' : 'is-normal');

  setText('statusIcon',  isAnaemic ? '🔴' : '🟢');
  setText('statusLabel', isAnaemic ? 'Anaemic Detected' : 'Non-Anaemic');
  setText('statusDesc',  isAnaemic
    ? 'Your haemoglobin level is below the normal threshold. Please consult a healthcare professional.'
    : 'Your haemoglobin level appears within normal range. Keep maintaining a healthy lifestyle.'
  );
  setText('hbValue', `${hb} g/dL`);
  setText('hbRange',  getHbRange(parseFloat(hb)));

  // Gauge
  animateGauge(confidence);

  // Scale marker
  positionScaleMarker(parseFloat(hb));

  // Image
  const imgEl = document.getElementById('resultImage');
  if (imgEl) imgEl.src = imageUrl;

  // Advice
  renderAdvice(isAnaemic, parseFloat(hb));
}

function animateGauge(confidence) {
  const arc  = document.getElementById('gaugeArc');
  const text = document.getElementById('gaugeText');
  if (!arc || !text) return;

  const pct    = Math.min(Math.max(confidence, 0), 1);
  const total  = 251; // half-circle circumference
  const offset = total - pct * total;

  setTimeout(() => {
    arc.style.strokeDashoffset = offset;
    // Colour coding
    if (pct >= 0.8)      arc.style.stroke = '#16A34A';
    else if (pct >= 0.6) arc.style.stroke = '#EAB308';
    else                 arc.style.stroke = '#DC2626';
  }, 200);

  // Animate number
  let current = 0;
  const target = Math.round(pct * 100);
  const step   = target / 60;
  const timer  = setInterval(() => {
    current = Math.min(current + step, target);
    text.textContent = Math.round(current) + '%';
    if (current >= target) clearInterval(timer);
  }, 16);
}

function positionScaleMarker(hb) {
  const marker = document.getElementById('scaleMarker');
  if (!marker) return;
  // Scale: 0–7 severe, 7–10 moderate, 10–12 mild, 12–16+ normal
  // Map 0–16 to 0–100%
  const pct = Math.min(Math.max((hb / 16) * 100, 0), 100);
  setTimeout(() => { marker.style.left = pct + '%'; }, 300);
}

function getHbRange(hb) {
  if (hb < 7)  return 'Severe Anaemia';
  if (hb < 10) return 'Moderate Anaemia';
  if (hb < 12) return 'Mild Anaemia';
  if (hb < 14) return 'Normal (lower end)';
  return 'Normal';
}

function renderAdvice(isAnaemic, hb) {
  const adviceContent = document.getElementById('adviceContent');
  if (!adviceContent) return;

  let items;
  if (!isAnaemic)     items = ADVICE_DATA.normal;
  else if (hb < 7)    items = ADVICE_DATA.severe;
  else                items = ADVICE_DATA.anaemic;

  adviceContent.innerHTML = `
    <div class="advice-items">
      ${items.map(item => `
        <div class="advice-item">
          <div class="adv-icon">${item.icon}</div>
          <h4>${item.title}</h4>
          <p>${item.text}</p>
        </div>
      `).join('')}
    </div>
  `;
}

function generateDemoResult() {
  return {
    hb_level:   '10.4',
    prediction: 'anaemic',
    confidence:  0.89,
    image_url:   '',
    created_at:  new Date().toISOString(),
  };
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

/* ============================================================
   UPLOAD.JS
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  requireAuth();
  setupDropzone();
});

let selectedFile = null;

/* ── Dropzone setup ── */
function setupDropzone() {
  const dropzone  = document.getElementById('dropzone');
  const fileInput = document.getElementById('fileInput');
  if (!dropzone) return;

  dropzone.addEventListener('click', (e) => {
    if (!e.target.closest('button') && !selectedFile) fileInput.click();
  });
  fileInput.addEventListener('change', () => {
    if (fileInput.files[0]) handleFileSelect(fileInput.files[0]);
  });
  dropzone.addEventListener('dragover', (e) => {
    e.preventDefault(); dropzone.classList.add('drag-over');
  });
  dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag-over'));
  dropzone.addEventListener('drop', (e) => {
    e.preventDefault(); dropzone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  });
}

function handleFileSelect(file) {
  const ALLOWED = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
  const MAX_MB  = 10;

  if (!ALLOWED.includes(file.type)) {
    showError('Please upload a JPG, PNG, or WEBP image.'); return;
  }
  if (file.size > MAX_MB * 1024 * 1024) {
    showError(`Image must be under ${MAX_MB}MB.`); return;
  }

  selectedFile = file;
  showPreview(file);
  document.getElementById('submitBtn').disabled = false;
  hideMessages();
}

function showPreview(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    document.getElementById('previewImg').src  = e.target.result;
    document.getElementById('previewName').textContent = file.name;
    document.getElementById('previewSize').textContent = formatBytes(file.size);
    document.getElementById('dropzoneContent').style.display = 'none';
    document.getElementById('previewContent').style.display  = 'flex';
  };
  reader.readAsDataURL(file);
}

function clearImage() {
  selectedFile = null;
  document.getElementById('fileInput').value = '';
  document.getElementById('dropzoneContent').style.display = 'flex';
  document.getElementById('previewContent').style.display  = 'none';
  document.getElementById('previewImg').src = '';
  document.getElementById('submitBtn').disabled = true;
  hideMessages();
}

/* ── Submit ── */
async function submitImage() {
  if (!selectedFile) { showError('Please select an image first.'); return; }

  showProcessing(true);

  try {
    // Step 1: Upload
    await delay(600);
    markStep(1, 'done'); markStep(2, 'active');
    updateProcessStep('Running AI model...');

    const uploadData = await apiUpload(selectedFile);
    await delay(400);

    // Step 2: Predict
    markStep(2, 'done'); markStep(3, 'active');
    updateProcessStep('Computing results...');

    const result = await apiPredict(uploadData.image_id);
    await delay(400);
    markStep(3, 'done');

    // Store result and redirect
    localStorage.setItem('haemo_last_result', JSON.stringify(result));
    window.location.href = 'result.html';

  } catch (err) {
    showProcessing(false);
    showError(err.message || 'Analysis failed. Please try again.');
  }
}

/* ── Camera ── */
let stream = null;

async function openCamera() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    document.getElementById('video').srcObject = stream;
    document.getElementById('cameraModal').style.display = 'flex';
  } catch (err) {
    showError('Camera access denied. Please allow camera permissions.');
  }
}

function closeCamera() {
  if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; }
  document.getElementById('cameraModal').style.display = 'none';
}

function capturePhoto() {
  const video  = document.getElementById('video');
  const canvas = document.getElementById('captureCanvas');
  canvas.width  = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext('2d').drawImage(video, 0, 0);
  canvas.toBlob((blob) => {
    const file = new File([blob], `capture_${Date.now()}.jpg`, { type: 'image/jpeg' });
    closeCamera();
    handleFileSelect(file);
  }, 'image/jpeg', 0.92);
}

/* ── Processing UI ── */
function showProcessing(show) {
  document.getElementById('processingOverlay').style.display = show ? 'flex' : 'none';
  if (show) {
    markStep(1, 'active'); markStep(2, ''); markStep(3, '');
    updateProcessStep('Validating image...');
  }
}

function markStep(n, state) {
  const el = document.getElementById(`ps${n}`);
  if (!el) return;
  el.className = 'pstep' + (state ? ' ' + state : '');
}

function updateProcessStep(msg) {
  const el = document.getElementById('processStep');
  if (el) el.textContent = msg;
}

/* ── Messages ── */
function showError(msg) {
  const el = document.getElementById('errorMsg');
  if (el) { el.textContent = '⚠ ' + msg; el.style.display = 'flex'; }
  const ok = document.getElementById('successMsg');
  if (ok) ok.style.display = 'none';
}
function hideMessages() {
  ['errorMsg','successMsg'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });
}

/* ── Utils ── */
function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

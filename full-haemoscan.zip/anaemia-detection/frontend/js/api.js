/* ============================================================
   API.JS — Central API utility for HaemoScan
   ============================================================ */

const API_BASE = 'http://localhost:5000/api';  // Change to deployed URL in production

/* ── Token helpers ── */
function getToken()          { return localStorage.getItem('haemo_token'); }
function setToken(token)     { localStorage.setItem('haemo_token', token); }
function removeToken()       { localStorage.removeItem('haemo_token'); localStorage.removeItem('haemo_user'); }
function setUser(user)       { localStorage.setItem('haemo_user', JSON.stringify(user)); }
function getUser()           { 
  try { return JSON.parse(localStorage.getItem('haemo_user')); } 
  catch { return null; } 
}
function isLoggedIn()        { return !!getToken(); }

/* ── Route guard — redirect if not logged in ── */
function requireAuth() {
  if (!isLoggedIn()) { window.location.href = '../pages/login.html'; }
}

/* ── Base fetch wrapper ── */
async function apiFetch(endpoint, options = {}) {
  const token = getToken();
  const headers = { 'Content-Type': 'application/json', ...options.headers };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const response = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || data.error || `HTTP ${response.status}`);
  }
  return data;
}

/* ── Auth APIs ── */
async function apiLogin(email, password) {
  return apiFetch('/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  });
}

async function apiSignup(userData) {
  return apiFetch('/signup', {
    method: 'POST',
    body: JSON.stringify(userData)
  });
}

/* ── Upload API (multipart) ── */
async function apiUpload(file) {
  const token = getToken();
  const formData = new FormData();
  formData.append('file', file);

  const response = await fetch(`${API_BASE}/upload`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` },
    body: formData
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || 'Upload failed');
  return data;
}

/* ── Predict API ── */
async function apiPredict(imageId) {
  return apiFetch('/predict', {
    method: 'POST',
    body: JSON.stringify({ image_id: imageId })
  });
}

/* ── History API ── */
async function apiHistory() {
  return apiFetch('/history', { method: 'GET' });
}

/* ── Logout ── */
function logout() {
  removeToken();
  window.location.href = '../index.html';
}

/* ── Bind logout buttons ── */
document.addEventListener('DOMContentLoaded', () => {
  ['logoutBtn', 'logoutBtn2'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('click', (e) => { e.preventDefault(); logout(); });
  });
});

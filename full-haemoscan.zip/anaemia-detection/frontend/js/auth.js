/* ============================================================
   AUTH.JS — Login & Signup logic
   ============================================================ */

function showError(msg) {
  const el = document.getElementById('errorMsg');
  const ok = document.getElementById('successMsg');
  if (ok)  { ok.style.display  = 'none'; }
  if (el)  { el.textContent = '⚠ ' + msg; el.style.display = 'flex'; }
}
function showSuccess(msg) {
  const el = document.getElementById('successMsg');
  const er = document.getElementById('errorMsg');
  if (er)  { er.style.display  = 'none'; }
  if (el)  { el.textContent = '✓ ' + msg; el.style.display = 'flex'; }
}
function setLoading(loading) {
  const btn = document.getElementById('submitBtn');
  const txt = document.getElementById('btnText');
  const spn = document.getElementById('btnSpinner');
  if (!btn) return;
  btn.disabled = loading;
  if (txt) txt.style.display = loading ? 'none' : 'inline';
  if (spn) spn.style.display = loading ? 'inline-block' : 'none';
}

function togglePw() {
  const inp = document.getElementById('password');
  if (!inp) return;
  inp.type = inp.type === 'password' ? 'text' : 'password';
}

/* ── Handle Login ── */
async function handleLogin(email, password) {
  setLoading(true);
  try {
    const data = await apiLogin(email, password);
    setToken(data.token);
    setUser(data.user);
    showSuccess('Login successful! Redirecting...');
    setTimeout(() => { window.location.href = 'dashboard.html'; }, 800);
  } catch (err) {
    showError(err.message || 'Invalid credentials. Please try again.');
  } finally {
    setLoading(false);
  }
}

/* ── Handle Signup ── */
async function handleSignup(userData) {
  setLoading(true);
  try {
    const data = await apiSignup(userData);
    setToken(data.token);
    setUser(data.user);
    showSuccess('Account created! Redirecting...');
    setTimeout(() => { window.location.href = 'dashboard.html'; }, 800);
  } catch (err) {
    showError(err.message || 'Signup failed. Please try again.');
  } finally {
    setLoading(false);
  }
}

/* ── Redirect if already logged in ── */
document.addEventListener('DOMContentLoaded', () => {
  if (isLoggedIn()) { window.location.href = 'dashboard.html'; }
});

"""
============================================================
  routes/auth_routes.py — POST /signup, POST /login
============================================================
"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token
from werkzeug.security import generate_password_hash, check_password_hash
import re

from database import get_connection

auth_bp = Blueprint('auth', __name__)


def is_valid_email(email: str) -> bool:
    return bool(re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', email))


# ── POST /api/signup ─────────────────────────────────────────
@auth_bp.route('/signup', methods=['POST'])
def signup():
    data = request.get_json(silent=True) or {}

    # Validation
    required = ['first_name', 'last_name', 'email', 'password']
    for field in required:
        if not data.get(field, '').strip():
            return jsonify({'message': f'{field.replace("_"," ").title()} is required.'}), 400

    email    = data['email'].strip().lower()
    password = data['password'].strip()

    if not is_valid_email(email):
        return jsonify({'message': 'Invalid email address.'}), 400
    if len(password) < 8:
        return jsonify({'message': 'Password must be at least 8 characters.'}), 400

    hashed = generate_password_hash(password)

    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)

        # Check duplicate
        cur.execute('SELECT id FROM users WHERE email = %s', (email,))
        if cur.fetchone():
            return jsonify({'message': 'Email already registered.'}), 409

        cur.execute(
            '''INSERT INTO users (first_name, last_name, email, password, age, gender)
               VALUES (%s, %s, %s, %s, %s, %s)''',
            (
                data['first_name'].strip(),
                data['last_name'].strip(),
                email,
                hashed,
                data.get('age'),
                data.get('gender'),
            )
        )
        conn.commit()
        user_id = cur.lastrowid

        user_obj = {
            'id':         user_id,
            'first_name': data['first_name'].strip(),
            'last_name':  data['last_name'].strip(),
            'email':      email,
            'age':        data.get('age'),
            'gender':     data.get('gender'),
        }
        token = create_access_token(identity=str(user_id))
        return jsonify({'token': token, 'user': user_obj}), 201

    except Exception as e:
        conn.rollback()
        return jsonify({'message': f'Server error: {str(e)}'}), 500
    finally:
        cur.close()
        conn.close()


# ── POST /api/login ──────────────────────────────────────────
@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json(silent=True) or {}
    email    = data.get('email', '').strip().lower()
    password = data.get('password', '').strip()

    if not email or not password:
        return jsonify({'message': 'Email and password are required.'}), 400

    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute('SELECT * FROM users WHERE email = %s', (email,))
        user = cur.fetchone()

        if not user or not check_password_hash(user['password'], password):
            return jsonify({'message': 'Invalid email or password.'}), 401

        user_obj = {
            'id':         user['id'],
            'first_name': user['first_name'],
            'last_name':  user['last_name'],
            'email':      user['email'],
            'age':        user['age'],
            'gender':     user['gender'],
        }
        token = create_access_token(identity=str(user['id']))
        return jsonify({'token': token, 'user': user_obj}), 200

    except Exception as e:
        return jsonify({'message': f'Server error: {str(e)}'}), 500
    finally:
        cur.close()
        conn.close()

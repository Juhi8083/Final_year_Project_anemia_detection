"""
============================================================
  routes/upload_routes.py — POST /upload
============================================================
"""
from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename
import os, uuid

from utils.image_validator import validate_eye_image

upload_bp = Blueprint('upload', __name__)

ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'webp'}


def allowed_file(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# ── POST /api/upload ─────────────────────────────────────────
@upload_bp.route('/upload', methods=['POST'])
@jwt_required()
def upload():
    if 'file' not in request.files:
        return jsonify({'message': 'No file part in request.'}), 400

    file = request.files['file']

    if file.filename == '':
        return jsonify({'message': 'No file selected.'}), 400

    if not allowed_file(file.filename):
        return jsonify({'message': 'Invalid file type. Please upload JPG, PNG, or WEBP.'}), 400

    # Read file bytes for validation
    file_bytes = file.read()
    file.seek(0)

    # Image validation (eye region check)
    valid, reason = validate_eye_image(file_bytes)
    if not valid:
        return jsonify({'message': f'Image validation failed: {reason}'}), 422

    # Save file with unique name
    ext       = secure_filename(file.filename).rsplit('.', 1)[-1].lower()
    unique_fn = f"{uuid.uuid4().hex}.{ext}"
    save_path = os.path.join(current_app.config['UPLOAD_FOLDER'], unique_fn)
    file.save(save_path)

    return jsonify({
        'message':    'Image uploaded successfully.',
        'image_id':   unique_fn,
        'image_path': save_path,
    }), 200

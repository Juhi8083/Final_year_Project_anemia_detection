"""
============================================================
  routes/predict_routes.py — POST /predict
============================================================
"""
from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
import os

from database import get_connection
from utils.predictor import run_prediction

predict_bp = Blueprint('predict', __name__)


# ── POST /api/predict ────────────────────────────────────────
@predict_bp.route('/predict', methods=['POST'])
@jwt_required()
def predict():
    user_id = get_jwt_identity()
    data    = request.get_json(silent=True) or {}
    image_id = data.get('image_id', '').strip()

    if not image_id:
        return jsonify({'message': 'image_id is required.'}), 400

    image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], image_id)
    if not os.path.exists(image_path):
        return jsonify({'message': 'Image not found. Please upload again.'}), 404

    # Run ML prediction
    try:
        result = run_prediction(image_path, current_app.config['MODEL_PATH'])
    except Exception as e:
        return jsonify({'message': f'Prediction error: {str(e)}'}), 500

    hb_level   = result['hb_level']
    prediction = result['prediction']   # 'anaemic' | 'non_anaemic'
    confidence = result['confidence']

    # Persist to DB
    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(
            '''INSERT INTO scans (user_id, image_path, hb_level, prediction, confidence)
               VALUES (%s, %s, %s, %s, %s)''',
            (user_id, image_path, hb_level, prediction, confidence)
        )
        conn.commit()
        scan_id = cur.lastrowid
    except Exception as e:
        conn.rollback()
        return jsonify({'message': f'DB error: {str(e)}'}), 500
    finally:
        cur.close()
        conn.close()

    # Build image URL (relative or absolute depending on deployment)
    image_url = f"/api/image/{image_id}"

    return jsonify({
        'id':         scan_id,
        'hb_level':   round(hb_level, 2),
        'prediction': prediction,
        'confidence': round(confidence, 4),
        'image_url':  image_url,
        'image_id':   image_id,
        'created_at': None,   # Will be set on read from DB
        'advice':     _get_advice(hb_level, prediction),
    }), 200


def _get_advice(hb: float, prediction: str) -> str:
    if prediction == 'non_anaemic':
        return "Your haemoglobin level is within the normal range. Maintain a balanced iron-rich diet and stay hydrated."
    if hb < 7:
        return "Severe anaemia detected. Please seek immediate medical attention. Iron infusion or transfusion may be required."
    if hb < 10:
        return "Moderate anaemia detected. Consult a doctor for iron supplements, B12, and folate evaluation."
    return "Mild anaemia detected. Increase intake of iron-rich foods (spinach, lentils, red meat) and Vitamin C. Consult a physician."

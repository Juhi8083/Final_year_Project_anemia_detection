"""
============================================================
  routes/history_routes.py — GET /history, GET /image/<id>
============================================================
"""
from flask import Blueprint, jsonify, send_from_directory, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
import os

from database import get_connection

history_bp = Blueprint('history', __name__)


# ── GET /api/history ─────────────────────────────────────────
@history_bp.route('/history', methods=['GET'])
@jwt_required()
def get_history():
    user_id = get_jwt_identity()

    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(
            '''SELECT id, hb_level, prediction, confidence, image_path, created_at
               FROM scans
               WHERE user_id = %s
               ORDER BY created_at DESC
               LIMIT 50''',
            (user_id,)
        )
        rows = cur.fetchall()

        # Serialise datetime
        history = []
        for row in rows:
            history.append({
                'id':         row['id'],
                'hb_level':   round(float(row['hb_level'] or 0), 2),
                'prediction': row['prediction'],
                'confidence': round(float(row['confidence'] or 0), 4),
                'image_url':  f"/api/image/{os.path.basename(row['image_path'])}",
                'created_at': row['created_at'].isoformat() if row['created_at'] else None,
            })

        return jsonify({'history': history, 'count': len(history)}), 200

    except Exception as e:
        return jsonify({'message': f'Error fetching history: {str(e)}'}), 500
    finally:
        cur.close()
        conn.close()


# ── GET /api/image/<filename> ────────────────────────────────
@history_bp.route('/image/<filename>', methods=['GET'])
@jwt_required()
def serve_image(filename):
    upload_folder = current_app.config['UPLOAD_FOLDER']
    safe_name = os.path.basename(filename)   # Prevent directory traversal
    if not os.path.exists(os.path.join(upload_folder, safe_name)):
        return jsonify({'message': 'Image not found.'}), 404
    return send_from_directory(upload_folder, safe_name)

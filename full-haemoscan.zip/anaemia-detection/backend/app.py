"""
============================================================
  app.py — HaemoScan Flask Backend Entry Point
============================================================
"""
from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from dotenv import load_dotenv
import os

from database import init_db
from routes.auth_routes    import auth_bp
from routes.upload_routes  import upload_bp
from routes.predict_routes import predict_bp
from routes.history_routes import history_bp

load_dotenv()

def create_app():
    app = Flask(__name__)

    # ── Configuration ──────────────────────────────────────────
    app.config['SECRET_KEY']            = os.getenv('SECRET_KEY', 'haemoscan-secret-change-in-prod')
    app.config['JWT_SECRET_KEY']        = os.getenv('JWT_SECRET_KEY', 'jwt-secret-change-in-prod')
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = False          # Set timedelta in prod
    app.config['MAX_CONTENT_LENGTH']    = 10 * 1024 * 1024  # 10 MB upload limit
    app.config['UPLOAD_FOLDER']         = os.path.join(os.path.dirname(__file__), 'uploads')
    app.config['MODEL_PATH']            = os.path.join(os.path.dirname(__file__), 'ml_model', 'saved_model', 'haemoscan_cnn.h5')

    # ── Extensions ─────────────────────────────────────────────
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    JWTManager(app)

    # ── Upload folder ───────────────────────────────────────────
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    # ── Database ────────────────────────────────────────────────
    init_db()

    # ── Blueprints ──────────────────────────────────────────────
    app.register_blueprint(auth_bp,    url_prefix='/api')
    app.register_blueprint(upload_bp,  url_prefix='/api')
    app.register_blueprint(predict_bp, url_prefix='/api')
    app.register_blueprint(history_bp, url_prefix='/api')

    # ── Health check ────────────────────────────────────────────
    @app.route('/api/health')
    def health():
        return {'status': 'ok', 'service': 'HaemoScan API', 'version': '1.0.0'}, 200

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)

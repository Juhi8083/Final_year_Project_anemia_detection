"""
============================================================
  utils/predictor.py
  Loads the trained CNN model and runs inference on an image.
  Falls back to a rule-based demo prediction if model file
  is not yet available (during development / testing).
============================================================
"""
import os
import numpy as np
import cv2
from typing import Dict

# TensorFlow / Keras — lazy import so app starts even without GPU
_model_cache = {}


def _load_model(model_path: str):
    """Load and cache the Keras model."""
    if model_path in _model_cache:
        return _model_cache[model_path]
    try:
        import tensorflow as tf
        model = tf.keras.models.load_model(model_path)
        _model_cache[model_path] = model
        print(f"✅  Model loaded from {model_path}")
        return model
    except Exception as e:
        print(f"⚠  Model load failed: {e}. Using demo predictor.")
        return None


def preprocess_image(image_path: str, target_size: tuple = (224, 224)) -> np.ndarray:
    """
    Load, resize, and normalise the image for CNN input.
    Returns float32 array of shape (1, 224, 224, 3).
    """
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Cannot read image: {image_path}")

    # Convert BGR → RGB
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # Resize to model input
    img = cv2.resize(img, target_size, interpolation=cv2.INTER_AREA)

    # Normalise [0,255] → [0,1]
    img = img.astype(np.float32) / 255.0

    # Add batch dimension
    return np.expand_dims(img, axis=0)


def run_prediction(image_path: str, model_path: str) -> Dict:
    """
    Run full prediction pipeline.
    Returns dict: { hb_level, prediction, confidence }
    """
    model = _load_model(model_path) if os.path.exists(model_path) else None

    if model is not None:
        return _model_predict(model, image_path)
    else:
        return _demo_predict(image_path)


def _model_predict(model, image_path: str) -> Dict:
    """Real model inference."""
    img_array = preprocess_image(image_path)

    # Model output: [hb_regression, classification_prob]
    # Adjust based on your actual model architecture
    outputs = model.predict(img_array, verbose=0)

    if isinstance(outputs, list) and len(outputs) == 2:
        # Dual-output model: (hb_level, anaemia_prob)
        hb_level   = float(np.squeeze(outputs[0]))
        anaemia_prob = float(np.squeeze(outputs[1]))
    elif outputs.shape[-1] == 2:
        # Single output with 2 values: [hb, prob]
        hb_level     = float(outputs[0][0])
        anaemia_prob = float(outputs[0][1])
    else:
        # Single sigmoid output — treat as probability only
        anaemia_prob = float(np.squeeze(outputs))
        hb_level     = _prob_to_hb(anaemia_prob)

    # Clamp Hb to physiological range
    hb_level = float(np.clip(hb_level, 4.0, 18.0))

    prediction = 'anaemic' if hb_level < 12.0 else 'non_anaemic'
    confidence  = anaemia_prob if prediction == 'anaemic' else (1.0 - anaemia_prob)

    return {
        'hb_level':   hb_level,
        'prediction': prediction,
        'confidence': float(np.clip(confidence, 0.5, 0.99)),
    }


def _demo_predict(image_path: str) -> Dict:
    """
    Rule-based demo predictor using colour analysis of conjunctiva.
    Used when the trained model file is not available.
    """
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Cannot read image: {image_path}")

    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    h, w    = img_rgb.shape[:2]

    # Sample central region
    cy, cx  = h // 2, w // 2
    region  = img_rgb[max(0,cy-60):cy+60, max(0,cx-80):cx+80]

    r_mean  = float(region[:,:,0].mean())
    g_mean  = float(region[:,:,1].mean())
    b_mean  = float(region[:,:,2].mean())

    # Redness ratio — pale conjunctiva has lower redness
    total       = r_mean + g_mean + b_mean + 1e-6
    redness     = r_mean / total
    brightness  = total / 3.0

    # Simple heuristic: high redness + brightness → healthy Hb
    # Pale, whitish → low Hb
    hb_level = 6.0 + (redness * 15.0) + (brightness / 255.0 * 3.0)
    hb_level = float(np.clip(hb_level, 4.0, 18.0))

    # Add slight noise for realism
    import random
    hb_level += random.uniform(-0.8, 0.8)
    hb_level  = round(float(np.clip(hb_level, 4.0, 18.0)), 1)

    is_anaemic = hb_level < 12.0
    confidence  = round(min(0.5 + abs(hb_level - 12.0) * 0.04, 0.97), 4)

    return {
        'hb_level':   hb_level,
        'prediction': 'anaemic' if is_anaemic else 'non_anaemic',
        'confidence': confidence,
    }


def _prob_to_hb(prob: float) -> float:
    """Convert anaemia probability to approximate Hb level."""
    # prob=1.0 (definitely anaemic) → Hb ≈ 7
    # prob=0.0 (non-anaemic)        → Hb ≈ 14
    return 14.0 - (prob * 7.0)

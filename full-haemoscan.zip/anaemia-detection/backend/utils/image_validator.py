"""
============================================================
  utils/image_validator.py
  Validates that the uploaded image is likely a conjunctiva
  / eye image and meets quality standards.
============================================================
"""
import cv2
import numpy as np
from typing import Tuple


def validate_eye_image(file_bytes: bytes) -> Tuple[bool, str]:
    """
    Validates the uploaded image.
    Returns (is_valid: bool, reason: str)
    """
    # 1. Decode image
    nparr = np.frombuffer(file_bytes, np.uint8)
    img   = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    if img is None:
        return False, "Could not decode image. Please upload a valid JPG or PNG."

    h, w = img.shape[:2]

    # 2. Minimum resolution check
    if h < 100 or w < 100:
        return False, "Image is too small (minimum 100×100 px). Please upload a clearer image."

    # 3. Blur / sharpness check using Laplacian variance
    gray      = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    laplacian = cv2.Laplacian(gray, cv2.CV_64F).var()
    if laplacian < 40:
        return False, "Image appears blurry. Please retake a sharper photo."

    # 4. Brightness check (avoid completely dark / overexposed)
    mean_brightness = gray.mean()
    if mean_brightness < 20:
        return False, "Image is too dark. Please ensure adequate lighting."
    if mean_brightness > 240:
        return False, "Image is overexposed. Avoid direct flash on the eye."

    # 5. Reddish region check — conjunctiva is pinkish/red
    # Convert to HSV and check for presence of red/pink hues
    hsv         = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    red_mask1   = cv2.inRange(hsv, (0,  40, 40), (10,  255, 255))
    red_mask2   = cv2.inRange(hsv, (160, 40, 40), (180, 255, 255))
    pink_mask   = cv2.inRange(hsv, (140, 20, 120), (180, 180, 255))
    red_pixels  = cv2.countNonZero(red_mask1) + cv2.countNonZero(red_mask2) + cv2.countNonZero(pink_mask)
    total_pixels = h * w

    red_ratio   = red_pixels / total_pixels
    if red_ratio < 0.01:
        return False, (
            "No eye region detected. Please ensure the lower eyelid conjunctiva "
            "(inner pink surface) is visible in the image."
        )

    return True, "Image is valid."

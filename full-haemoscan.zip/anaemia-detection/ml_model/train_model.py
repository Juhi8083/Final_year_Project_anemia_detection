"""
============================================================
  ml_model/train_model.py
  CNN Training Script for Anaemia Detection via Conjunctiva

  Architecture: Transfer Learning with ResNet50 (ImageNet)
  Outputs:
    - Classification: anaemic / non-anaemic  (sigmoid)
    - Regression:     Hb level in g/dL       (linear)

  Dataset expected layout:
    data/
      train/
        anaemic/       *.jpg
        non_anaemic/   *.jpg
      val/
        anaemic/       *.jpg
        non_anaemic/   *.jpg

  OR use the CSV-based loader with hb_level labels.
============================================================
"""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers, callbacks
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns

# ── Config ────────────────────────────────────────────────────
IMG_SIZE    = (224, 224)
BATCH_SIZE  = 32
EPOCHS      = 30
LR          = 1e-4
NUM_CLASSES = 1        # Binary sigmoid
DATA_DIR    = 'data'
SAVE_PATH   = 'saved_model/haemoscan_cnn.h5'
SEED        = 42

tf.random.set_seed(SEED)
np.random.seed(SEED)

os.makedirs('saved_model', exist_ok=True)
os.makedirs('plots', exist_ok=True)


# ─────────────────────────────────────────────────────────────
# 1. DATA AUGMENTATION & GENERATORS
# ─────────────────────────────────────────────────────────────
def build_generators():
    train_datagen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=15,
        width_shift_range=0.1,
        height_shift_range=0.1,
        horizontal_flip=True,
        brightness_range=[0.8, 1.2],
        zoom_range=0.1,
        fill_mode='nearest',
    )
    val_datagen = ImageDataGenerator(rescale=1./255)

    train_gen = train_datagen.flow_from_directory(
        os.path.join(DATA_DIR, 'train'),
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='binary',
        seed=SEED,
    )
    val_gen = val_datagen.flow_from_directory(
        os.path.join(DATA_DIR, 'val'),
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='binary',
        shuffle=False,
    )
    return train_gen, val_gen


# ─────────────────────────────────────────────────────────────
# 2. MODEL ARCHITECTURE
# ─────────────────────────────────────────────────────────────
def build_model(mode='classification'):
    """
    mode='classification' → binary output (anaemic/non-anaemic)
    mode='dual'           → (classification, hb_regression) dual output
    """
    base = ResNet50(
        weights='imagenet',
        include_top=False,
        input_shape=(*IMG_SIZE, 3)
    )

    # Freeze base initially, fine-tune later
    base.trainable = False

    inputs = tf.keras.Input(shape=(*IMG_SIZE, 3))
    x      = base(inputs, training=False)
    x      = layers.GlobalAveragePooling2D()(x)
    x      = layers.Dense(512, activation='relu')(x)
    x      = layers.BatchNormalization()(x)
    x      = layers.Dropout(0.4)(x)
    x      = layers.Dense(256, activation='relu')(x)
    x      = layers.Dropout(0.3)(x)

    if mode == 'dual':
        # Branch 1: classification
        cls_out = layers.Dense(1, activation='sigmoid', name='classification')(x)
        # Branch 2: Hb regression
        reg_x   = layers.Dense(128, activation='relu')(x)
        reg_out = layers.Dense(1, activation='linear', name='hb_regression')(reg_x)
        model   = models.Model(inputs, [cls_out, reg_out])
        model.compile(
            optimizer=optimizers.Adam(LR),
            loss={
                'classification': 'binary_crossentropy',
                'hb_regression':  'mse',
            },
            loss_weights={'classification': 1.0, 'hb_regression': 0.5},
            metrics={
                'classification': ['accuracy', tf.keras.metrics.AUC(name='auc')],
                'hb_regression':  ['mae'],
            }
        )
    else:
        out   = layers.Dense(1, activation='sigmoid', name='classification')(x)
        model = models.Model(inputs, out)
        model.compile(
            optimizer=optimizers.Adam(LR),
            loss='binary_crossentropy',
            metrics=['accuracy', tf.keras.metrics.AUC(name='auc')],
        )

    return model, base


# ─────────────────────────────────────────────────────────────
# 3. CALLBACKS
# ─────────────────────────────────────────────────────────────
def build_callbacks():
    return [
        callbacks.ModelCheckpoint(
            SAVE_PATH,
            monitor='val_accuracy',
            save_best_only=True,
            verbose=1,
        ),
        callbacks.EarlyStopping(
            monitor='val_loss',
            patience=7,
            restore_best_weights=True,
            verbose=1,
        ),
        callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.3,
            patience=3,
            min_lr=1e-7,
            verbose=1,
        ),
        callbacks.TensorBoard(log_dir='logs/', histogram_freq=1),
    ]


# ─────────────────────────────────────────────────────────────
# 4. FINE-TUNING
# ─────────────────────────────────────────────────────────────
def fine_tune(model, base_model, train_gen, val_gen):
    """Unfreeze top layers of ResNet for fine-tuning."""
    print("\n🔧  Fine-tuning top ResNet layers...")

    # Unfreeze last 30 layers
    base_model.trainable = True
    for layer in base_model.layers[:-30]:
        layer.trainable = False

    model.compile(
        optimizer=optimizers.Adam(LR / 10),
        loss='binary_crossentropy',
        metrics=['accuracy', tf.keras.metrics.AUC(name='auc')],
    )

    history_ft = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=10,
        callbacks=build_callbacks(),
    )
    return history_ft


# ─────────────────────────────────────────────────────────────
# 5. EVALUATION & PLOTS
# ─────────────────────────────────────────────────────────────
def plot_history(history, name='training'):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    ax1.plot(history.history['accuracy'],     label='Train Acc')
    ax1.plot(history.history['val_accuracy'], label='Val Acc')
    ax1.set_title('Model Accuracy'); ax1.set_xlabel('Epoch'); ax1.legend()

    ax2.plot(history.history['loss'],     label='Train Loss')
    ax2.plot(history.history['val_loss'], label='Val Loss')
    ax2.set_title('Model Loss'); ax2.set_xlabel('Epoch'); ax2.legend()

    plt.tight_layout()
    plt.savefig(f'plots/{name}_history.png', dpi=150)
    plt.show()
    print(f"📊  Plot saved to plots/{name}_history.png")


def evaluate_model(model, val_gen):
    print("\n📋  Evaluation on validation set:")
    preds  = model.predict(val_gen, verbose=1)
    labels = (preds > 0.5).astype(int).flatten()
    true   = val_gen.classes

    print(classification_report(true, labels, target_names=['Non-Anaemic', 'Anaemic']))

    cm = confusion_matrix(true, labels)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Reds',
                xticklabels=['Non-Anaemic','Anaemic'],
                yticklabels=['Non-Anaemic','Anaemic'])
    plt.title('Confusion Matrix')
    plt.savefig('plots/confusion_matrix.png', dpi=150)
    plt.show()


# ─────────────────────────────────────────────────────────────
# 6. MAIN
# ─────────────────────────────────────────────────────────────
def main():
    print("=" * 60)
    print("  HaemoScan — CNN Training Script")
    print("=" * 60)

    # Check data directory
    if not os.path.exists(DATA_DIR):
        print(f"⚠  Data directory '{DATA_DIR}' not found.")
        print("   Please organise your dataset as follows:")
        print("   data/train/anaemic/     ← conjunctiva images of anaemic patients")
        print("   data/train/non_anaemic/ ← conjunctiva images of non-anaemic patients")
        print("   data/val/anaemic/")
        print("   data/val/non_anaemic/")
        return

    # Build generators
    train_gen, val_gen = build_generators()
    print(f"\n✅  Training samples:   {train_gen.n}")
    print(f"✅  Validation samples: {val_gen.n}")
    print(f"   Class mapping: {train_gen.class_indices}")

    # Build model
    model, base_model = build_model(mode='classification')
    model.summary()

    # Phase 1: Train with frozen base
    print("\n🚀  Phase 1: Training with frozen ResNet base...")
    history = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=EPOCHS,
        callbacks=build_callbacks(),
    )
    plot_history(history, 'phase1')

    # Phase 2: Fine-tune
    history_ft = fine_tune(model, base_model, train_gen, val_gen)
    plot_history(history_ft, 'phase2_finetune')

    # Evaluate
    evaluate_model(model, val_gen)

    # Save final model
    model.save(SAVE_PATH)
    print(f"\n✅  Model saved to: {SAVE_PATH}")
    print("=" * 60)


if __name__ == '__main__':
    main()

# 🔬 HaemoScan — AI-Powered Anaemia Detection System
### Final Year Major Project | Computer Science / Biomedical Engineering

> Non-invasive haemoglobin estimation using deep learning analysis of conjunctiva images

---

## 📁 Project Structure

```
anaemia-detection/
├── frontend/
│   ├── index.html              ← Home page
│   ├── pages/
│   │   ├── login.html          ← Login page
│   │   ├── signup.html         ← Registration page
│   │   ├── dashboard.html      ← User dashboard + charts
│   │   ├── upload.html         ← Image upload + camera
│   │   └── result.html         ← Prediction result page
│   ├── css/
│   │   ├── global.css          ← Shared styles, variables, nav
│   │   ├── home.css            ← Home page styles
│   │   ├── auth.css            ← Login/signup styles
│   │   ├── dashboard.css       ← Dashboard styles
│   │   ├── upload.css          ← Upload page styles
│   │   └── result.css          ← Result page styles
│   └── js/
│       ├── api.js              ← Central API fetch utility
│       ├── auth.js             ← Login/signup logic
│       ├── dashboard.js        ← Dashboard + charts logic
│       ├── upload.js           ← Drag-drop + camera logic
│       ├── result.js           ← Result rendering logic
│       └── home.js             ← Home animations
│
├── backend/
│   ├── app.py                  ← Flask app factory
│   ├── database.py             ← MySQL connection pool + schema
│   ├── routes/
│   │   ├── auth_routes.py      ← POST /signup, POST /login
│   │   ├── upload_routes.py    ← POST /upload
│   │   ├── predict_routes.py   ← POST /predict
│   │   └── history_routes.py   ← GET /history, GET /image/<id>
│   ├── utils/
│   │   ├── image_validator.py  ← CV-based eye image validation
│   │   └── predictor.py        ← CNN inference + demo fallback
│   ├── uploads/                ← Uploaded images (auto-created)
│   ├── requirements.txt
│   └── .env.example
│
└── ml_model/
    ├── train_model.py          ← Full CNN training script
    ├── requirements.txt
    ├── saved_model/            ← haemoscan_cnn.h5 placed here
    ├── data/
    │   ├── train/
    │   │   ├── anaemic/
    │   │   └── non_anaemic/
    │   └── val/
    │       ├── anaemic/
    │       └── non_anaemic/
    └── notebooks/
        └── anaemia_detection_eda.ipynb
```

---

## ⚙️ Prerequisites

| Tool | Version |
|------|---------|
| Python | 3.10+ |
| MySQL | 8.0+ |
| Node.js | Not required (plain HTML/JS) |
| Git | Latest |

---

## 🚀 Step-by-Step Setup Guide

### STEP 1 — Clone the Project

```bash
git clone https://github.com/yourusername/haemoscan.git
cd haemoscan
```

---

### STEP 2 — MySQL Database Setup

```sql
-- Open MySQL prompt or MySQL Workbench
-- The app will auto-create the DB, but you need the MySQL user ready

mysql -u root -p

-- (Optional) Create a dedicated DB user
CREATE USER 'haemo_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON haemoscan_db.* TO 'haemo_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

> The Flask app auto-creates the `haemoscan_db` database and tables on first run.

---

### STEP 3 — Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Configure environment variables
cp .env.example .env
```

Now **edit `.env`** with your actual values:
```env
SECRET_KEY=your-super-secret-key-32chars
JWT_SECRET_KEY=another-secret-key-32chars
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=haemoscan_db
```

```bash
# Run the Flask server
python app.py
```

✅ You should see:
```
✅  Database initialised successfully.
 * Running on http://0.0.0.0:5000
```

---

### STEP 4 — Frontend Setup

The frontend is **static HTML/CSS/JS** — no build step needed.

**Option A — Open directly in browser:**
```
Open frontend/index.html in your browser
```

**Option B — Serve with a local server (recommended for CORS):**
```bash
# Python HTTP server (from frontend/ folder)
cd frontend
python -m http.server 3000

# Then open: http://localhost:3000
```

**Option C — VS Code Live Server extension** (easiest):
- Install "Live Server" extension in VS Code
- Right-click `index.html` → Open with Live Server

---

### STEP 5 — Connect Frontend to Backend

In `frontend/js/api.js`, line 5:
```js
// Development
const API_BASE = 'http://localhost:5000/api';

// Production — replace with your deployed backend URL
// const API_BASE = 'https://your-app.onrender.com/api';
```

---

### STEP 6 — ML Model Training

```bash
cd ml_model

# Create virtual environment (or use backend's)
python -m venv ml_env
source ml_env/bin/activate     # or ml_env\Scripts\activate on Windows

pip install -r requirements.txt
```

**Organise your dataset:**
```
ml_model/data/
├── train/
│   ├── anaemic/         ← 500–1000+ conjunctiva images of anaemic patients
│   └── non_anaemic/     ← 500–1000+ images of non-anaemic patients
└── val/
    ├── anaemic/         ← 100–200 images (20% split)
    └── non_anaemic/     ← 100–200 images
```

**Recommended public datasets:**
- [Anaemia Dataset — Kaggle](https://www.kaggle.com/datasets/orvile/anemia-dataset) 
- [Eye Conjunctiva Dataset](https://github.com/topics/conjunctiva-anaemia)
- Use your own clinical data with patient consent

```bash
# Train the model
python train_model.py
```

After training, the model saves to:
```
ml_model/saved_model/haemoscan_cnn.h5
```

Copy it to the backend:
```bash
cp ml_model/saved_model/haemoscan_cnn.h5 backend/ml_model/saved_model/
```

> **Without the model file**, the system uses a colour-analysis fallback predictor for demo purposes.

---

## 🌐 API Reference

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/signup` | Create account |
| POST | `/api/login` | Login, returns JWT token |

**POST /api/signup** body:
```json
{
  "first_name": "Aarav",
  "last_name": "Sharma",
  "email": "aarav@example.com",
  "password": "secret123",
  "age": 22,
  "gender": "male"
}
```

**POST /api/login** body:
```json
{ "email": "aarav@example.com", "password": "secret123" }
```

Response includes `token` (JWT) and `user` object.

---

### Scan Endpoints (require `Authorization: Bearer <token>`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/upload` | Upload eye image (multipart/form-data) |
| POST | `/api/predict` | Run CNN inference |
| GET  | `/api/history` | Fetch user's past scans |
| GET  | `/api/image/<id>` | Serve uploaded image |
| GET  | `/api/health` | API health check |

**POST /api/predict** body:
```json
{ "image_id": "uuid-returned-from-upload.jpg" }
```

**Response:**
```json
{
  "id": 14,
  "hb_level": 9.8,
  "prediction": "anaemic",
  "confidence": 0.923,
  "image_url": "/api/image/abc123.jpg",
  "advice": "Moderate anaemia detected. Consult a doctor..."
}
```

---

## ☁️ Deployment Guide

### Backend → Render.com (Free tier)

1. Push backend code to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect your repo, set:
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:create_app()`
4. Add environment variables (same as `.env`)
5. Add a MySQL database (or use PlanetScale / Railway MySQL)

### Frontend → Netlify (Free)

1. Go to [netlify.com](https://netlify.com) → New site from Git
2. Base directory: `frontend`
3. Build command: _(leave blank)_
4. Publish directory: `frontend`
5. After deploy, update `API_BASE` in `js/api.js` to your Render URL

### Alternative: Vercel + Railway

- **Frontend** → Vercel (drag & drop `frontend/` folder)
- **Backend** → Railway (deploy Flask directly)
- **Database** → Railway MySQL plugin

---

## 🧪 Testing the API (without frontend)

```bash
# Health check
curl http://localhost:5000/api/health

# Signup
curl -X POST http://localhost:5000/api/signup \
  -H "Content-Type: application/json" \
  -d '{"first_name":"Test","last_name":"User","email":"test@test.com","password":"test1234","age":25,"gender":"male"}'

# Login
curl -X POST http://localhost:5000/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"test1234"}'
# → Copy the token from response

# Upload image
curl -X POST http://localhost:5000/api/upload \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -F "file=@/path/to/eye_image.jpg"
# → Copy image_id from response

# Predict
curl -X POST http://localhost:5000/api/predict \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{"image_id":"returned-image-id.jpg"}'
```

---

## 🤖 CNN Model Architecture

```
Input (224×224×3)
     │
ResNet50 (ImageNet pretrained, frozen initially)
     │
GlobalAveragePooling2D
     │
Dense(512, relu) → BatchNorm → Dropout(0.4)
     │
Dense(256, relu) → Dropout(0.3)
     │
Dense(1, sigmoid)  ← Binary classification (anaemic / non-anaemic)
```

**Training strategy:**
1. Phase 1: Freeze ResNet50, train head layers for 30 epochs
2. Phase 2: Unfreeze last 30 ResNet layers, fine-tune at LR/10

**Key metrics targeted:**
- Accuracy: > 92%
- AUC-ROC: > 0.95
- Sensitivity (Recall for anaemic): > 90%

---

## 🏥 Haemoglobin Reference Values

| Category | Hb Level (g/dL) | Population |
|----------|-----------------|------------|
| Severe Anaemia | < 7.0 | All |
| Moderate Anaemia | 7.0 – 9.9 | All |
| Mild Anaemia | 10.0 – 11.9 | Women / Children |
| Mild Anaemia | 10.0 – 12.9 | Men |
| Normal | ≥ 12.0 | Women |
| Normal | ≥ 13.0 | Men |

*(WHO reference values)*

---

## ⚠️ Medical Disclaimer

HaemoScan is developed for **educational and research purposes only** as part of a final year academic project. It is **not a certified medical device** and should **not replace clinical diagnosis**. Always consult a qualified healthcare professional for medical decisions.

---

## 📝 Tech Stack Summary

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JS |
| Backend | Python 3.10, Flask 3.0 |
| Database | MySQL 8.0 |
| AI/ML | TensorFlow 2.16, ResNet50 |
| Image Processing | OpenCV 4.10 |
| Auth | JWT (flask-jwt-extended) |
| Charts | Chart.js |
| Deployment | Netlify + Render / Railway |

---

*Built with ❤️ for the Final Year Major Project*
